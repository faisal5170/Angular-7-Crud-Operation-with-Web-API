export class CrudTable {
    Id: number;
    Name: string;
    PhoneNumber: string;
    Age: string;
}
