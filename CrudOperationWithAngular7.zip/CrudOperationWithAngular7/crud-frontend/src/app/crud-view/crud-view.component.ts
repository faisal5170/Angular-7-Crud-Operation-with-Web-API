import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-view',
  templateUrl: './crud-view.component.html',
  styleUrls: ['./crud-view.component.css']
})
export class CrudViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
